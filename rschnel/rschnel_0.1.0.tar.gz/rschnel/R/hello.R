#' add 2 numbers together
#' @export
dodawanie <- function(x, y) {
  x + y
}
