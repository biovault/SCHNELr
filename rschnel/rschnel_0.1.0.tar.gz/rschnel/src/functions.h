#ifndef FUNCTIONS_H
#define FUNCTION_H

//' Multiply 2 numbers
//' @param x, first number
//' @param y, second number
// [[Rcpp::export]]
int mnozenie(int x, int y);

#endif
