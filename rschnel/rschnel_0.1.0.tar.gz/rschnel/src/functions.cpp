#include "functions.h"
#include <Rcpp.h>
using namespace Rcpp;

int mnozenie(int x, int y) {
  return x * y;
}
